var App = require('./components/App');
var React = require('react');
var ReactDOM = require('react-dom');
var AppAPI = require('./util/AppAPI.js');

ReactDOM.render(

<App/>,document.getElementById('app')
);