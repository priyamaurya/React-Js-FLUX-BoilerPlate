var React = require('react');
AppActions = require('../action/AppAction');
AppStore = require('../stores/AppStore');

function getAppState(){
  return{
    
  }
}
var App = React.createClass({

	getInitialState:function(){

		return getAppState();

	},

 

componentDidMount :function(){
  AppStore.addChangeListener(this._onChange);
},

componentUnMount :function(){

AppStore.removeChangeListener(this._onChange);
},

  render :function(){
  	return( 
  		<div>
  			My App
  		</div>

  		);
  },

  onChange :function(){

  	this.setState(getAppState());
  }

});

module.exports = App;
